"""
near only support javascript
"""